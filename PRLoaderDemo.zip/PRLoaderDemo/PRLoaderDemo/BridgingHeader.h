//
//  BridgingHeader.h
//  PRLoaderDemo
//
//  Created by Rati on 16/06/17.
//  Copyright © 2017 Ratti. All rights reserved.
//

#ifndef BridgingHeader_h
#define BridgingHeader_h

#import "DGActivityIndicatorView.h"

#endif /* BridgingHeader_h */
